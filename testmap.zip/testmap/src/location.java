public class location {
    int x;

}
