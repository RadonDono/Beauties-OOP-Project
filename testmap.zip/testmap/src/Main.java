import java.util.Scanner;

public class Main {
    public static void main(String args[]){
        map m=new map();
        Scanner sc=new Scanner(System.in);
        m.show_pass(m.get_location(sc.nextInt()),m.get_location(sc.nextInt()));
    }
}
